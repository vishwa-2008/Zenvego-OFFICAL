import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.svg'],
        manifest: {
          name: 'Zenvego - Hyperlocal Agrarian Grid',
          short_name: 'Zenvego',
          description:
            'Hyperlocal marketplace connecting customers, growers, and delivery partners.',
          theme_color: '#0f5238',
          background_color: '#fff8f6',
          display: 'standalone',
          orientation: 'portrait',
          start_url: '/',
          icons: [
            {
              src: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=zenvego%20leaf%20logo%20green%20minimal&image_size=square_hd',
              sizes: '192x192',
              type: 'image/png',
            },
            {
              src: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=zenvego%20leaf%20logo%20green%20minimal&image_size=square_hd',
              sizes: '512x512',
              type: 'image/png',
            },
          ],
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
