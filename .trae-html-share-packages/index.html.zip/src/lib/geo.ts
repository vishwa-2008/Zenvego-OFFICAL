// Real-time geolocation & live tracking using the browser Geolocation API.
// Zero cost, works on mobile devices with GPS.
export interface GeoCoords {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

export function isGeolocationSupported(): boolean {
  return typeof navigator !== 'undefined' && 'geolocation' in navigator;
}

export function getCurrentPosition(): Promise<GeoCoords> {
  return new Promise((resolve, reject) => {
    if (!isGeolocationSupported()) {
      reject(new Error('Geolocation is not supported by this device.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          timestamp: pos.timestamp,
        });
      },
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 }
    );
  });
}

export function watchPosition(
  onUpdate: (coords: GeoCoords) => void,
  onError?: (err: GeolocationPositionError) => void
): number {
  if (!isGeolocationSupported()) {
    onError?.({ code: 0, message: 'Geolocation not supported' } as any);
    return -1;
  }
  return navigator.geolocation.watchPosition(
    (pos) =>
      onUpdate({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
        timestamp: pos.timestamp,
      }),
    onError,
    { enableHighAccuracy: true, maximumAge: 3000, timeout: 15000 }
  );
}

export function clearWatch(id: number): void {
  if (id >= 0 && isGeolocationSupported()) {
    navigator.geolocation.clearWatch(id);
  }
}

// Haversine distance in km
export function distanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
