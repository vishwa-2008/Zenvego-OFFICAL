import React, { useState, useEffect } from 'react';
import { ViewState, LoggedInUser } from '../types';
import { login, register } from '../lib/auth';
import { handleImageError } from '../utils/imageFallback';

interface LoginViewProps {
  setView: (view: ViewState) => void;
  addToast: (msg: string) => void;
  preselectedRole: 'customer' | 'seller' | 'delivery' | null;
  setPreselectedRole: (role: 'customer' | 'seller' | 'delivery' | null) => void;
  onLoginSuccess: (user: LoggedInUser) => void;
}

export default function LoginView({
  setView,
  addToast,
  preselectedRole,
  onLoginSuccess,
}: LoginViewProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [selectedRole, setSelectedRole] = useState<'customer' | 'seller' | 'delivery'>(() => {
    if (preselectedRole) return preselectedRole;
    return 'customer';
  });

  useEffect(() => {
    if (preselectedRole) setSelectedRole(preselectedRole);
  }, [preselectedRole]);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'register') {
        if (password !== confirmPassword) {
          setError('Passwords do not match.');
          setLoading(false);
          return;
        }
        const res = await register(name, email, password, selectedRole);
        if (!res.ok) {
          setError(res.error || 'Registration failed.');
          setLoading(false);
          return;
        }
        addToast('Account created! Please sign in.');
        setMode('login');
        setLoading(false);
        return;
      }

      const res = await login(email, password);
      if (!res.ok) {
        setError(res.error || 'Login failed.');
        setLoading(false);
        return;
      }
      addToast(`Welcome back, ${res.user?.name}!`);
      onLoginSuccess({
        id: res.user!.id,
        name: res.user!.name,
        email: res.user!.email,
        role: res.user!.role,
        avatar: res.user!.avatar,
        idVerified: res.user!.idVerified,
        selfiePhoto: res.user!.selfiePhoto,
      });
    } catch (err: any) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fff8f6] flex flex-col md:flex-row overflow-hidden font-sans">
      {/* Brand panel */}
      <div className="hidden md:flex md:w-1/2 relative flex-col justify-between p-10 bg-gradient-to-br from-[#0f5238] to-[#1a7a52] text-white overflow-hidden">
        <div>
          <div className="flex items-center gap-3">
            <span className="text-4xl">🌿</span>
            <div>
              <h1 className="text-3xl font-black tracking-wider">ZENVEGO</h1>
              <p className="text-sm opacity-80">Hyperlocal Agrarian Grid</p>
            </div>
          </div>
        </div>

        <div className="relative my-8 flex-1 flex items-center justify-center">
          <img
            src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&q=80&w=600"
            alt="Fresh local produce"
            className="w-full max-w-md rounded-3xl shadow-2xl object-cover"
            onError={(e) => handleImageError(e, 'produce')}
          />
        </div>

        <div>
          <p className="text-lg font-semibold leading-relaxed">
            "Direct from farm to your table. Supporting local growers, building stronger communities."
          </p>
          <p className="text-sm opacity-70 mt-2">— Rukmini Swaminathan, Rooftop Grower</p>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col justify-center items-center py-10 px-6 bg-[#fffaf8]">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center md:hidden">
            <h1 className="text-2xl font-black tracking-wider text-[#0f5238]">ZENVEGO</h1>
            <p className="text-xs text-gray-500">Hyperlocal Agrarian Grid</p>
          </div>

          <div className="text-center space-y-1">
            <h2 className="text-2xl font-black text-[#271810]">
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </h2>
            <p className="text-xs text-gray-500">
              {mode === 'login'
                ? 'Access your Zenvego account'
                : 'Join the hyperlocal marketplace'}
            </p>
          </div>

          {/* Role selection */}
          <div>
            <label className="text-[10px] font-extrabold text-[#7a5743] uppercase tracking-wider">
              Select Your Role
            </label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {(['customer', 'seller', 'delivery'] as const).map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setSelectedRole(role)}
                  className={`p-3 rounded-2xl border-2 text-center transition-all ${
                    selectedRole === role
                      ? 'border-[#0f5238] bg-[#0f5238]/5 shadow-sm'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <span className="material-symbols-outlined text-[#0f5238] text-[22px] block mx-auto">
                    {role === 'customer' ? 'shopping_basket' : role === 'seller' ? 'agriculture' : 'local_shipping'}
                  </span>
                  <p className="font-bold text-xs text-[#271810] mt-1">
                    {role === 'customer' ? 'Customer' : role === 'seller' ? 'Seller' : 'Delivery'}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {mode === 'register' && (
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your full name"
                  className="w-full bg-white border border-gray-200 px-3.5 py-3 rounded-xl text-sm focus:border-[#0f5238] focus:outline-none"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-white border border-gray-200 px-3.5 py-3 rounded-xl text-sm focus:border-[#0f5238] focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-white border border-gray-200 px-3.5 py-3 rounded-xl text-sm focus:border-[#0f5238] focus:outline-none"
              />
            </div>

            {mode === 'register' && (
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">Confirm Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white border border-gray-200 px-3.5 py-3 rounded-xl text-sm focus:border-[#0f5238] focus:outline-none"
                />
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs px-3 py-2 rounded-xl">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#0f5238] hover:bg-[#0c402c] disabled:opacity-60 text-white text-sm font-bold py-3.5 rounded-xl transition-colors shadow-sm"
            >
              {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <div className="text-center text-sm">
            <span className="text-gray-500">
              {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            </span>
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setError('');
              }}
              className="text-[#0f5238] font-bold hover:underline"
            >
              {mode === 'login' ? 'Sign Up' : 'Sign In'}
            </button>
          </div>

          <button
            type="button"
            onClick={() => setView('market-home')}
            className="w-full text-xs text-gray-400 hover:text-gray-600"
          >
            ← Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}
