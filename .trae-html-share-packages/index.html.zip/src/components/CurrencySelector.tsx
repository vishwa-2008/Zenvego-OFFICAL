import React from 'react';
import { Currency } from '../utils/currency';

interface CurrencySelectorProps {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  className?: string;
}

// Currency selection has been moved to the developer console panel.
// This component is intentionally hidden from page headers.
export default function CurrencySelector(_props: CurrencySelectorProps) {
  return null;
}
