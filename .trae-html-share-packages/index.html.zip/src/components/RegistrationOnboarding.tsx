import React, { useState, useEffect } from 'react';
import { ViewState, LoggedInUser } from '../types';
import { captureFromCamera, readFileAsDataUrl } from '../lib/photo';
import { getCurrentPosition } from '../lib/geo';
import { verifySelfie } from '../lib/auth';
import { updateProfile } from '../lib/auth';

interface RegistrationOnboardingProps {
  setView: (view: ViewState) => void;
  sessionUser: LoggedInUser | null;
  setSessionUser: (user: LoggedInUser | null) => void;
  addToast: (msg: string) => void;
}

export default function RegistrationOnboarding({
  setView,
  sessionUser,
  setSessionUser,
  addToast,
}: RegistrationOnboardingProps) {
  const [stage, setStage] = useState<'choose-role' | 'delivery' | 'customer' | 'seller'>(
    'choose-role'
  );

  useEffect(() => {
    if (sessionUser?.role) setStage(sessionUser.role);
  }, [sessionUser]);

  const [submitting, setSubmitting] = useState(false);

  // --- Photo verification (shared for seller & delivery) ---
  const [selfiePhoto, setSelfiePhoto] = useState<string>('');
  const [capturing, setCapturing] = useState(false);

  const handleCaptureSelfie = async () => {
    try {
      setCapturing(true);
      const dataUrl = await captureFromCamera();
      setSelfiePhoto(dataUrl);
      addToast('Selfie captured successfully.');
    } catch (err) {
      addToast('Camera access denied. Please upload a photo instead.');
    } finally {
      setCapturing(false);
    }
  };

  const handleUploadSelfie = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setSelfiePhoto(dataUrl);
      addToast('Photo uploaded successfully.');
    } catch {
      addToast('Failed to process image.');
    }
  };

  // --- Customer state ---
  const [customerData, setCustomerData] = useState({
    fullName: sessionUser?.name || '',
    phone: '',
    address: '',
    lat: 0,
    lng: 0,
  });
  const [gpsLoading, setGpsLoading] = useState(false);

  const handleFetchLocation = async () => {
    setGpsLoading(true);
    try {
      const pos = await getCurrentPosition();
      setCustomerData((prev) => ({ ...prev, lat: pos.lat, lng: pos.lng }));
      addToast(`Location acquired: ${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}`);
    } catch {
      addToast('Unable to get location. Please enter address manually.');
    } finally {
      setGpsLoading(false);
    }
  };

  // --- Seller state ---
  const [sellerData, setSellerData] = useState({
    fullName: sessionUser?.name || '',
    phone: '',
    farmName: '',
    category: 'Organic Vegetables',
    description: '',
    aadhaarNo: '',
    panNo: '',
  });

  // --- Delivery state ---
  const [deliveryData, setDeliveryData] = useState({
    fullName: sessionUser?.name || '',
    phone: '',
    vehicleType: 'Bike',
    licenseNo: '',
    bankAccount: '',
    ifsc: '',
  });

  const finishOnboarding = async (role: 'customer' | 'seller' | 'delivery') => {
    if (!sessionUser) return;
    setSubmitting(true);

    try {
      // Save selfie verification
      if (selfiePhoto) {
        await verifySelfie(sessionUser.id, selfiePhoto);
      }

      // Save profile data
      const profileData =
        role === 'customer'
          ? customerData
          : role === 'seller'
          ? sellerData
          : deliveryData;
      await updateProfile(sessionUser.id, {
        name:
          role === 'customer'
            ? customerData.fullName || sessionUser.name
            : role === 'seller'
            ? sellerData.fullName || sessionUser.name
            : deliveryData.fullName || sessionUser.name,
        profileData,
      });

      setSessionUser({
        ...sessionUser,
        name:
          role === 'customer'
            ? customerData.fullName || sessionUser.name
            : role === 'seller'
            ? sellerData.fullName || sessionUser.name
            : deliveryData.fullName || sessionUser.name,
        idVerified: !!selfiePhoto,
        selfiePhoto: selfiePhoto || undefined,
      });

      addToast(`Account activated! Welcome as a ${role}.`);

      if (role === 'customer') setView('buyer-marketplace');
      else if (role === 'seller') setView('farmer-dashboard');
      else setView('delivery-dashboard');
    } catch {
      addToast('Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fafdfb] flex flex-col font-sans pb-10">
      <header className="w-full flex items-center justify-between p-5 max-w-4xl mx-auto border-b border-emerald-600/10">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('market-home')}>
          <span className="material-symbols-outlined text-emerald-600 text-[26px]">spa</span>
          <div>
            <span className="text-lg font-black tracking-widest text-[#271810]">ZENVEGO</span>
            <span className="text-[9px] uppercase tracking-wider text-emerald-700 font-bold block leading-none">
              Hyperlocal Agrarian Grid
            </span>
          </div>
        </div>
        <button
          onClick={() => setView('market-home')}
          className="text-xs bg-emerald-600/5 text-emerald-800 hover:bg-emerald-600/10 px-4 py-2 rounded-xl font-bold"
        >
          Back Home
        </button>
      </header>

      <div className="max-w-4xl w-full mx-auto px-4 mt-6 flex-grow">
        {stage === 'choose-role' && (
          <div className="w-full max-w-xl text-center space-y-6 mx-auto animate-fade-in">
            <div className="space-y-2">
              <h2 className="text-2xl md:text-3xl font-black text-[#271810]">Complete Your Setup</h2>
              <p className="text-xs text-gray-500 max-w-md mx-auto">
                Choose your role to finish onboarding and unlock your dashboard.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {([
                { role: 'customer', icon: 'shopping_basket', title: 'Customer', desc: 'Buy fresh produce from local growers.' },
                { role: 'seller', icon: 'agriculture', title: 'Seller / Farmer', desc: 'List your harvest and manage orders.' },
                { role: 'delivery', icon: 'local_shipping', title: 'Delivery Partner', desc: 'Deliver orders and earn on every trip.' },
              ] as const).map((r) => (
                <button
                  key={r.role}
                  onClick={() => setStage(r.role)}
                  className="bg-white border-2 border-gray-200 hover:border-emerald-600 p-5 rounded-2xl text-left space-y-3 hover:shadow-lg transition-all"
                >
                  <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <span className="material-symbols-outlined text-[22px]">{r.icon}</span>
                  </div>
                  <h4 className="font-bold text-sm">{r.title}</h4>
                  <p className="text-[10px] text-gray-500">{r.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* CUSTOMER ONBOARDING */}
        {stage === 'customer' && (
          <div className="max-w-lg mx-auto space-y-5 animate-fade-in">
            <h2 className="text-xl font-black text-[#271810]">Customer Onboarding</h2>
            <div className="space-y-3">
              <Field label="Full Name">
                <input
                  value={customerData.fullName}
                  onChange={(e) => setCustomerData({ ...customerData, fullName: e.target.value })}
                  className="input"
                  placeholder="Your name"
                />
              </Field>
              <Field label="Phone Number">
                <input
                  value={customerData.phone}
                  onChange={(e) => setCustomerData({ ...customerData, phone: e.target.value })}
                  className="input"
                  placeholder="10-digit mobile number"
                />
              </Field>
              <Field label="Delivery Address">
                <textarea
                  value={customerData.address}
                  onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })}
                  className="input"
                  rows={3}
                  placeholder="House no, street, landmark, city"
                />
              </Field>
              <button
                onClick={handleFetchLocation}
                disabled={gpsLoading}
                className="w-full bg-emerald-600/10 text-emerald-700 py-3 rounded-xl font-bold text-sm hover:bg-emerald-600/20 flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">my_location</span>
                {gpsLoading ? 'Detecting location...' : 'Use My Current Location'}
              </button>
              {customerData.lat !== 0 && (
                <p className="text-xs text-emerald-700">
                  Mapped: {customerData.lat.toFixed(4)}, {customerData.lng.toFixed(4)}
                </p>
              )}
            </div>
            <button
              onClick={() => finishOnboarding('customer')}
              disabled={submitting || !customerData.fullName}
              className="w-full bg-[#0f5238] hover:bg-[#0c402c] disabled:opacity-50 text-white py-3.5 rounded-xl font-bold text-sm"
            >
              {submitting ? 'Activating...' : 'Activate Customer Account'}
            </button>
          </div>
        )}

        {/* SELLER ONBOARDING */}
        {stage === 'seller' && (
          <div className="max-w-lg mx-auto space-y-5 animate-fade-in">
            <h2 className="text-xl font-black text-[#271810]">Seller / Farmer Onboarding</h2>
            <PhotoVerification
              selfiePhoto={selfiePhoto}
              capturing={capturing}
              onCapture={handleCaptureSelfie}
              onUpload={handleUploadSelfie}
              required
            />
            <div className="space-y-3">
              <Field label="Full Name">
                <input
                  value={sellerData.fullName}
                  onChange={(e) => setSellerData({ ...sellerData, fullName: e.target.value })}
                  className="input"
                />
              </Field>
              <Field label="Phone Number">
                <input
                  value={sellerData.phone}
                  onChange={(e) => setSellerData({ ...sellerData, phone: e.target.value })}
                  className="input"
                  placeholder="10-digit mobile"
                />
              </Field>
              <Field label="Farm / Brand Name">
                <input
                  value={sellerData.farmName}
                  onChange={(e) => setSellerData({ ...sellerData, farmName: e.target.value })}
                  className="input"
                  placeholder="e.g. Sunny Hills Organic"
                />
              </Field>
              <Field label="Primary Category">
                <select
                  value={sellerData.category}
                  onChange={(e) => setSellerData({ ...sellerData, category: e.target.value })}
                  className="input"
                >
                  <option>Organic Vegetables</option>
                  <option>Fruits</option>
                  <option>Dairy</option>
                  <option>Grains & Pulses</option>
                  <option>Honey & Sweets</option>
                  <option>Bakery</option>
                </select>
              </Field>
              <Field label="Farm Description">
                <textarea
                  value={sellerData.description}
                  onChange={(e) => setSellerData({ ...sellerData, description: e.target.value })}
                  className="input"
                  rows={2}
                  placeholder="Tell buyers about your farm"
                />
              </Field>
              <Field label="Aadhaar Number">
                <input
                  value={sellerData.aadhaarNo}
                  onChange={(e) => setSellerData({ ...sellerData, aadhaarNo: e.target.value })}
                  className="input"
                  placeholder="XXXX XXXX XXXX"
                />
              </Field>
              <Field label="PAN Number">
                <input
                  value={sellerData.panNo}
                  onChange={(e) => setSellerData({ ...sellerData, panNo: e.target.value.toUpperCase() })}
                  className="input"
                  placeholder="ABCDE1234F"
                />
              </Field>
            </div>
            <button
              onClick={() => finishOnboarding('seller')}
              disabled={submitting || !selfiePhoto || !sellerData.fullName}
              className="w-full bg-[#0f5238] hover:bg-[#0c402c] disabled:opacity-50 text-white py-3.5 rounded-xl font-bold text-sm"
            >
              {submitting ? 'Activating...' : 'Activate Seller Account'}
            </button>
          </div>
        )}

        {/* DELIVERY ONBOARDING */}
        {stage === 'delivery' && (
          <div className="max-w-lg mx-auto space-y-5 animate-fade-in">
            <h2 className="text-xl font-black text-[#271810]">Delivery Partner Onboarding</h2>
            <PhotoVerification
              selfiePhoto={selfiePhoto}
              capturing={capturing}
              onCapture={handleCaptureSelfie}
              onUpload={handleUploadSelfie}
              required
            />
            <div className="space-y-3">
              <Field label="Full Name">
                <input
                  value={deliveryData.fullName}
                  onChange={(e) => setDeliveryData({ ...deliveryData, fullName: e.target.value })}
                  className="input"
                />
              </Field>
              <Field label="Phone Number">
                <input
                  value={deliveryData.phone}
                  onChange={(e) => setDeliveryData({ ...deliveryData, phone: e.target.value })}
                  className="input"
                  placeholder="10-digit mobile"
                />
              </Field>
              <Field label="Vehicle Type">
                <select
                  value={deliveryData.vehicleType}
                  onChange={(e) => setDeliveryData({ ...deliveryData, vehicleType: e.target.value })}
                  className="input"
                >
                  <option>Bike</option>
                  <option>Scooter</option>
                  <option>Car</option>
                  <option>Cycle</option>
                </select>
              </Field>
              <Field label="Driving License Number">
                <input
                  value={deliveryData.licenseNo}
                  onChange={(e) => setDeliveryData({ ...deliveryData, licenseNo: e.target.value.toUpperCase() })}
                  className="input"
                  placeholder="DL Number"
                />
              </Field>
              <Field label="Bank Account Number">
                <input
                  value={deliveryData.bankAccount}
                  onChange={(e) => setDeliveryData({ ...deliveryData, bankAccount: e.target.value })}
                  className="input"
                  placeholder="Account number"
                />
              </Field>
              <Field label="IFSC Code">
                <input
                  value={deliveryData.ifsc}
                  onChange={(e) => setDeliveryData({ ...deliveryData, ifsc: e.target.value.toUpperCase() })}
                  className="input"
                  placeholder="e.g. HDFC0000512"
                />
              </Field>
            </div>
            <button
              onClick={() => finishOnboarding('delivery')}
              disabled={submitting || !selfiePhoto || !deliveryData.fullName}
              className="w-full bg-[#0f5238] hover:bg-[#0c402c] disabled:opacity-50 text-white py-3.5 rounded-xl font-bold text-sm"
            >
              {submitting ? 'Activating...' : 'Activate Delivery Account'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] font-bold text-gray-500 uppercase">{label}</label>
      {children}
    </div>
  );
}

function PhotoVerification({
  selfiePhoto,
  capturing,
  onCapture,
  onUpload,
  required,
}: {
  selfiePhoto: string;
  capturing: boolean;
  onCapture: () => void;
  onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
}) {
  return (
    <div className="bg-white border-2 border-dashed border-emerald-300 rounded-2xl p-5 text-center space-y-3">
      <div className="flex items-center justify-center gap-2 text-emerald-700 font-bold text-sm">
        <span className="material-symbols-outlined">photo_camera</span>
        Photo Verification {required && <span className="text-red-500">*</span>}
      </div>
      {selfiePhoto ? (
        <img src={selfiePhoto} alt="Verification" className="w-32 h-32 object-cover rounded-xl mx-auto" />
      ) : (
        <div className="w-32 h-32 bg-gray-100 rounded-xl mx-auto flex items-center justify-center">
          <span className="material-symbols-outlined text-gray-400 text-[40px]">person</span>
        </div>
      )}
      <div className="flex gap-2 justify-center">
        <button
          onClick={onCapture}
          disabled={capturing}
          className="bg-emerald-600 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-emerald-700"
        >
          {capturing ? 'Capturing...' : 'Take Selfie'}
        </button>
        <label className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-xs font-bold hover:bg-gray-200 cursor-pointer">
          Upload Photo
          <input type="file" accept="image/*" onChange={onUpload} className="hidden" />
        </label>
      </div>
    </div>
  );
}
