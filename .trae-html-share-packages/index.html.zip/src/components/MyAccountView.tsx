import React, { useState, useEffect } from 'react';
import { ViewState, LoggedInUser } from '../types';
import { Currency, formatPrice } from '../utils/currency';
import CurrencySelector from './CurrencySelector';
import { handleImageError } from '../utils/imageFallback';
import { formatDistance, formatWeight } from '../utils/measurement';
import { getOrdersByCustomer, type OrderRecord } from '../lib/db';

interface MyAccountViewProps {
  setView: (view: ViewState) => void;
  addToast: (msg: string) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  sessionUser?: LoggedInUser | null;
  handleLogout?: () => void;
  measurementSystem?: 'US' | 'IND';
}

export default function MyAccountView({ 
  setView, 
  addToast, 
  currency, 
  setCurrency,
  sessionUser,
  handleLogout,
  measurementSystem = 'US'
}: MyAccountViewProps) {
  const [activeTab, setActiveTab] = useState('orders');
  const [showRecipeModal, setShowRecipeModal] = useState(false);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);

  useEffect(() => {
    if (!sessionUser?.id) {
      setOrdersLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const list = await getOrdersByCustomer(sessionUser.id);
        if (!cancelled) {
          // newest first
          list.sort((a, b) => b.createdAt - a.createdAt);
          setOrders(list);
        }
      } finally {
        if (!cancelled) setOrdersLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [sessionUser?.id]);

  // Deep interactive Courier Tracking Map & Chat System
  const [showTrackerModal, setShowTrackerModal] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { sender: 'courier', text: 'Hi Sarah! I am heading to Sunny Hills Organic to collect your heirloom tomatoes and bunch of carrots. See you soon!', time: '12m ago' },
    { sender: 'system', text: 'Alex River registered secure handoff QR code: ZEN-RELEASE-7749.', time: '10m ago' }
  ]);
  const [typedMessage, setTypedMessage] = useState('');
  const [isCalling, setIsCalling] = useState(false);

  const handleSendChatMessage = () => {
    if (!typedMessage.trim()) return;
    const userMsg = typedMessage;
    
    setChatMessages(prev => [
      ...prev,
      { sender: 'user', text: userMsg, time: 'Just Now' }
    ]);
    setTypedMessage('');

    // Simulated responses from driver Alex
    setTimeout(() => {
      let automatedReply = "Received! Sourcing from grower John and packing it carefully into secure thermal pouch.";
      if (userMsg.toLowerCase().includes('rotten') || userMsg.toLowerCase().includes('fresh')) {
        automatedReply = "Yes, John's crops are harvested fresh today. Soil is completely organic!";
      } else if (userMsg.toLowerCase().includes('slow') || userMsg.toLowerCase().includes('where')) {
        automatedReply = "Drafting route on the radar map now. The delivery timeline is active!";
      } else if (userMsg.toLowerCase().includes('qr') || userMsg.toLowerCase().includes('code')) {
        automatedReply = "I have the QR display ready. John Miller can scan it once I pull up at the barn.";
      }
      setChatMessages(prev => [
        ...prev,
        { sender: 'courier', text: automatedReply, time: 'Just Now' }
      ]);
    }, 1500);
  };

  const totalOrders = orders.length;
  const totalSpent = orders.reduce((sum, o) => sum + (o.total || 0), 0);
  const deliveredCount = orders.filter(o => o.status === 'delivered').length;
  const totalItems = orders.reduce((sum, o) => sum + (o.items?.length || 0), 0);

  const trackerStats = [
    { label: "Community Orders", value: String(totalOrders), unit: "bookings" },
    { label: "Items Purchased", value: String(totalItems), unit: "units" },
    { label: "Delivered", value: String(deliveredCount), unit: "orders" },
    { label: "Total Spent", value: formatPrice(totalSpent, currency), unit: currency }
  ];

  const recentBookings = orders.slice(0, 6).map((o) => ({
    id: o.orderNo || o.id,
    date: new Date(o.createdAt).toLocaleDateString(),
    status: o.status,
    courier: o.deliveryPartnerName || 'Unassigned',
    items: o.items.map((it) => ({ name: it.name, qty: `${it.quantity} ${it.unit}` })),
    amount: o.total,
  }));

  const statusMeta = (s: string) => {
    switch (s) {
      case 'placed': return { label: 'Order Placed', cls: 'bg-amber-100 text-amber-700' };
      case 'paid': return { label: 'Paid', cls: 'bg-blue-100 text-blue-700' };
      case 'assigned': return { label: 'Courier Assigned', cls: 'bg-indigo-100 text-indigo-700' };
      case 'picked': return { label: 'Picked Up', cls: 'bg-purple-100 text-purple-700' };
      case 'in_transit': return { label: 'In Transit', cls: 'bg-secondary-container text-white' };
      case 'delivered': return { label: 'Delivered', cls: 'bg-[#e2f5ec] text-primary' };
      case 'cancelled': return { label: 'Cancelled', cls: 'bg-red-100 text-red-700' };
      default: return { label: s, cls: 'bg-surface-container text-outline' };
    }
  };

  const favoritedFarmers = [
    {
      name: "Helen's Heritage Greenhouses",
      avgRange: formatDistance(3.4, measurementSystem),
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
      banner: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=400",
      produce: "Swedes, Dinosaur Kale, Bell Peppers",
      deliveries: 124
    }
  ];

  return (
    <div id="account-container" className="min-h-screen bg-[#fff8f6] flex flex-col font-sans">
      
      {/* Dynamic Profile Header */}
      <header className="bg-white border-b border-surface-container py-4 px-4 md:px-8 sticky top-0 z-40 shadow-sm flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('buyer-marketplace')}>
          <span className="material-symbols-outlined text-primary hover:bg-surface-container p-2 rounded-full">arrow_back</span>
          <div className="flex items-center gap-2">
            {sessionUser?.avatar ? (
              <img 
                src={sessionUser.avatar} 
                alt="" 
                onError={(e) => handleImageError(e, 'avatar')}
                className="w-7 h-7 rounded-full object-cover border border-primary/20"
              />
            ) : (
              <span className="material-symbols-outlined text-[28px] text-primary fill-icon">account_circle</span>
            )}
            <div>
              <h2 className="text-sm font-bold text-[#271810]">
                {sessionUser ? sessionUser.name : 'Sarah Jenkins'} / Profile Portal
              </h2>
              <p className="text-[9px] text-outline font-semibold uppercase tracking-wider">
                {sessionUser ? `Verified Member • ${sessionUser.email}` : 'Verified Consumer Since 2024'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <CurrencySelector currency={currency} setCurrency={setCurrency} />
          
          <button 
            onClick={() => setView('buyer-marketplace')}
            className="px-4 py-1.5 rounded-full text-xs font-bold text-white bg-primary hover:bg-primary-container shadow-sm flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[14px]">storefront</span>
            Go Sourcing
          </button>
          
          {sessionUser && (
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-full text-xs font-bold text-[#7a5743] hover:text-white bg-surface-container hover:bg-[#a24000] border border-[#a24000]/10 transition-all cursor-pointer"
            >
              Log Out
            </button>
          )}
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-grow p-4 md:p-8 max-w-5xl mx-auto w-full space-y-6">
        
        {/* Upper Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {trackerStats.map((stat, idx) => (
            <div key={idx} className="bg-white p-4 rounded-2xl border border-surface-container shadow-sm space-y-1">
              <span className="text-[10px] uppercase font-bold text-outline block">{stat.label}</span>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-black text-primary">{stat.value}</span>
                <span className="text-[10px] text-on-surface-variant">{stat.unit}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Live Courier Dispatch tracking */}
        <div className="bg-primary/5 border border-primary/20 rounded-3xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200" 
                alt="Alex Courier" 
                onError={(e) => handleImageError(e, 'avatar')}
                className="w-12 h-12 rounded-full object-cover border-2 border-primary"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></span>
            </div>
            
            <div className="space-y-0.5">
              <p className="text-xs uppercase font-bold text-secondary">Active Dispatch Notification</p>
              <h4 className="font-bold text-sm text-[#271810]">Alex River • Zenvego Neighborhood Courier</h4>
              <p className="text-[11px] text-on-surface-variant leading-relaxed">
                Courier expects completion at <strong>4:45 PM</strong>. Lock-box PIN generated: <code className="bg-surface-container px-1 rounded text-primary font-bold">#4910</code>
              </p>
            </div>
          </div>

          <div className="flex gap-2 w-full md:w-auto">
            <button 
              onClick={() => {
                setShowTrackerModal(true);
                addToast("📍 Mapped real-time GPS tracking dashboard to Courier Alex River.");
              }}
              className="flex-1 md:flex-none text-xs font-bold text-primary bg-surface-container-high hover:bg-surface-container-highest px-3.5 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">map</span>
              Track Map & Chat
            </button>
            <button 
              onClick={() => {
                setIsCalling(true);
                addToast("🛰️ Routing secure voice call tunnel to Alex River...");
              }}
              className="px-3 py-2 rounded-xl bg-primary hover:bg-primary-container text-white"
              title="Call Alex"
            >
              <span className="material-symbols-outlined text-[16px] leading-none">call</span>
            </button>
          </div>
        </div>

        {/* Outer Split Columns */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Recent Orders section */}
          <div className="md:col-span-7 space-y-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="material-symbols-outlined text-primary">receipt_long</span>
              <h3 className="font-extrabold text-on-surface text-base">Your Community Ledger Bookings</h3>
            </div>

            <div className="space-y-4">
              {ordersLoading ? (
                <div className="text-center py-10 text-sm text-on-surface-variant">Loading your orders…</div>
              ) : recentBookings.length === 0 ? (
                <div className="bg-white rounded-2xl p-8 border border-surface-container text-center">
                  <span className="material-symbols-outlined text-4xl text-outline/50">shopping_bag</span>
                  <p className="text-sm font-bold text-on-surface mt-2">No orders yet</p>
                  <p className="text-xs text-on-surface-variant mt-1">Your community ledger bookings will appear here.</p>
                  <button
                    onClick={() => setView('buyer-marketplace')}
                    className="mt-4 px-4 py-2 rounded-full text-xs font-bold text-white bg-primary"
                  >
                    Start Sourcing
                  </button>
                </div>
              ) : recentBookings.map((b) => {
                const sm = statusMeta(b.status);
                return (
                <div key={b.id} className="bg-white rounded-2xl p-5 border border-surface-container space-y-3 shadow-none">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-[10px] font-mono text-outline block">{b.date}</span>
                      <p className="font-bold text-xs text-on-surface">Reference {b.id}</p>
                    </div>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sm.cls}`}>
                      {sm.label}
                    </span>
                  </div>

                  <div className="bg-[#fff9f6] p-3 rounded-xl border border-surface-container-low space-y-1">
                    {b.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-on-surface-variant">
                        <span>{item.name}</span>
                        <span className="font-bold text-on-surface">{item.qty}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center text-xs pt-2 border-t border-surface-container-low">
                    <span className="text-outline">Assigned Courier: <strong>{b.courier}</strong></span>
                    <span className="font-extrabold text-primary">{formatPrice(b.amount, currency)}</span>
                  </div>
                </div>
                );
              })}
            </div>
          </div>

          {/* Right widgets */}
          <div className="md:col-span-5 space-y-6">
            
            {/* Ratatouille Recipe Card widget */}
            <div className="bg-white rounded-3xl border border-surface-container overflow-hidden shadow-sm">
              <div className="h-40 relative">
                <img 
                  src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=600" 
                  alt="Plated Ratatouille in Ceramic Bowl" 
                  referrerPolicy="no-referrer"
                  onError={(e) => handleImageError(e, 'produce')}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 left-3 bg-[#a24000] text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  AI Culinary suggestion
                </span>
              </div>
              <div className="p-5 space-y-3">
                <h4 className="font-bold text-on-surface text-sm">Provencal Vegetable Ratatouille</h4>
                <p className="text-[11px] text-on-surface-variant leading-relaxed">
                  Based on your purchase logs of organic heirlooms and purple brinjals, we generated a bespoke zero-waste family recipe.
                </p>
                <button 
                  onClick={() => setShowRecipeModal(true)}
                  className="w-full bg-[#faddce] hover:bg-[#ffe2d5] text-[#7c2f00] font-bold text-xs py-2 rounded-xl transition-colors"
                >
                  Show Ingredients & Methods
                </button>
              </div>
            </div>

            {/* Favorited growers */}
            <div className="space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-outline">Favorited Harvesters</h4>
              
              {favoritedFarmers.map((f, idx) => (
                <div key={idx} className="bg-white rounded-2xl overflow-hidden border border-surface-container shadow-none">
                  <div className="h-20 bg-cover bg-center" style={{ backgroundImage: `url(${f.banner})` }}></div>
                  <div className="p-4 flex gap-3 -mt-6">
                    <img 
                      src={f.avatar} 
                      alt={f.name} 
                      onError={(e) => handleImageError(e, 'avatar')}
                      className="w-10 h-10 rounded-full border-2 border-white object-cover" 
                    />
                    <div className="space-y-1 mt-6 flex-grow">
                      <h5 className="font-bold text-xs text-on-surface">{f.name}</h5>
                      <p className="text-[10px] text-outline">{f.avgRange} • Verified Supplier</p>
                      <p className="text-[10px] text-primary font-bold">Producing: {f.produce}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recipie popup Modal */}
      {showRecipeModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-surface-container">
              <div>
                <h3 className="font-extrabold text-[#271810] text-base">Provencal Heirloom Ratatouille</h3>
                <p className="text-[10px] text-[#7c2f00]">Matched with your vine tomato cart</p>
              </div>
              <button 
                onClick={() => setShowRecipeModal(false)}
                className="text-outline hover:text-on-surface"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-on-surface-variant">
              <div>
                <span className="font-bold text-[#271810]">Ingredients available in your order:</span>
                <ul className="list-disc pl-4 mt-1 space-y-1">
                  <li>3 Vine Heirloom Tomatoes (sliced thinly)</li>
                  <li>{formatWeight(1.5, measurementSystem)} Purple Brinjals / Eggplants (sliced)</li>
                  <li>1 bundle Dinosaur Kale (sautéed for serving base)</li>
                </ul>
              </div>

              <div>
                <span className="font-bold text-[#271810]">Required pantry addition:</span>
                <p className="mt-0.5">Extra virgin olive oil, 2 cloves minced garlic, fresh basil, and coarse sea salt.</p>
              </div>

              <div className="pt-2 border-t border-surface-container space-y-2">
                <p className="font-bold text-[#271810]">Chef's Methods:</p>
                <ol className="list-decimal pl-4 space-y-1.5 font-normal text-on-surface-variant">
                  <li>Preheat standard oven to 375°F. Arrange tomato and eggplant slices sequentially in circular patterns inside shallow baking dish.</li>
                  <li>Drizzle with robust local olive oil, minced garlic, sea salt, and minced basil leaves.</li>
                  <li>Cover with parchment paper and bake for 40 minutes until veggies are tender. Serve hot on beds of braised dynamic dinosaur kale!</li>
                </ol>
              </div>
            </div>

            <button 
              onClick={() => {
                setShowRecipeModal(false);
                addToast("Recipe steps saved to your local recipe book.");
              }}
              className="w-full bg-primary text-white font-bold py-2.5 rounded-xl text-xs mt-3"
            >
              Close recipe
            </button>
          </div>
        </div>
      )}

      {/* REAL-TIME DYNAMIC COURIER TRACKER & LIVE CHAT TOOL PANEL */}
      {showTrackerModal && (
        <div className="fixed inset-0 bg-[#271810]/75 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in text-on-surface">
          <div className="bg-[#fff8f6] border-2 border-[#ff5c3e]/20 text-[#271810] rounded-[32px] p-6 max-w-3xl w-full grid grid-cols-1 md:grid-cols-12 gap-6 shadow-2xl relative">
            <button
              type="button"
              onClick={() => setShowTrackerModal(false)}
              className="absolute top-4 right-4 bg-gray-200/50 hover:bg-gray-200 w-8 h-8 rounded-full flex items-center justify-center text-gray-700 font-bold z-10"
            >
              ✕
            </button>

            {/* Left Column: Live SVG Vector Radar Map */}
            <div className="md:col-span-7 bg-white border border-[#eddcd4] rounded-2.5xl p-4.5 space-y-4 flex flex-col justify-between">
              <div>
                <span className="bg-primary/10 text-primary text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full">
                  GPS MAP NODE TRACKING
                </span>
                <h4 className="text-sm font-black text-[#271810] mt-1.5 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">navigation</span>
                  Real-time Harvest Vector Map
                </h4>
                <p className="text-[10px] text-gray-500 leading-normal mt-0.5">Alex River is moving from Sunny Hills Farm to drop-off lockers.</p>
              </div>

              {/* Vector representation of active route coordinates */}
              <div className="bg-[#271810] rounded-2xl h-52 relative border border-[#ff5c3e]/10 overflow-hidden flex flex-col justify-between p-4 shadow-inner">
                {/* Simulated Grid Nodes lines */}
                <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 opacity-[0.06] pointer-events-none">
                  {[...Array(24)].map((_, i) => (
                    <div key={i} className="border border-white"></div>
                  ))}
                </div>

                <div className="flex justify-between items-start z-10 text-[9px] font-mono text-white/50">
                  <div className="bg-emerald-600/20 text-emerald-400 p-1.5 rounded border border-emerald-500/10">
                    <span className="font-extrabold block">ORIGIN (A)</span>
                    <span className="text-white">Sunny Hills Organic</span>
                  </div>
                  <div className="bg-orange-600/20 text-[#ff5c3e] p-1.5 rounded border border-orange-500/10 text-right">
                    <span className="font-extrabold block">DESTINATION (B)</span>
                    <span className="text-white">Dropoff Locker #41</span>
                  </div>
                </div>

                {/* Animated Map Route Line and Courier marker */}
                <div className="absolute top-[52%] left-[20%] right-[20%] h-1 bg-dashed border-t-2 border-dashed border-emerald-400 opacity-65"></div>
                
                {/* Courier motorcycle pin marker moving */}
                <div className="absolute top-[44%] left-[46%] animate-bounce flex flex-col items-center">
                  <span className="bg-[#ff5c3e] text-white p-1 rounded-full shadow-lg border border-white">
                    <span className="material-symbols-outlined text-[14px] block">motorcycle</span>
                  </span>
                  <span className="bg-white text-[#271810] font-black font-mono text-[7.5px] px-1 py-0.5 rounded shadow-xs mt-1 uppercase">
                    ALEX (Courier)
                  </span>
                </div>

                <div className="z-10 flex justify-between items-end text-[9px] font-mono text-white/70">
                  <p>ETA Remaining: <strong className="text-[#ff5c3e]">~8 MINS</strong></p>
                  <p>Location: <strong className="text-emerald-400">Hub Boulevard Grid #12</strong></p>
                </div>
              </div>

              <div className="flex gap-2 divide-x divide-gray-150 text-xs text-gray-500 font-bold bg-gray-50 p-3 rounded-xl border border-gray-100 font-mono">
                <div className="flex-1 text-center">
                  <span className="text-[8.5px] uppercase text-gray-400 block tracking-wider leading-none">Job Rate</span>
                  <p className="text-[#271810] font-extrabold text-sm ml-1 mt-0.5">17.90 USD</p>
                </div>
                <div className="flex-grow pl-3 text-center">
                  <span className="text-[8.5px] uppercase text-gray-400 block tracking-wider leading-none">Security Pin</span>
                  <p className="text-[#271810] font-extrabold text-sm ml-1 mt-0.5">ZEN-RELEASE-7749</p>
                </div>
              </div>

            </div>

            {/* Right Column: Live Chat thread widget */}
            <div className="md:col-span-5 bg-white border border-[#eddcd4] rounded-2.5xl p-4.5 flex flex-col justify-between h-[420px]">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200" 
                    alt="Alex" 
                    className="w-10 h-10 rounded-full border border-gray-150 object-cover" 
                  />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></span>
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-[#271810]">Alex River (Rider)</h4>
                  <span className="text-[9px] text-[#ff5c3e] block font-semibold uppercase font-mono tracking-wider">ECO-TRANSIT COURIER</span>
                </div>
              </div>

              {/* Chat thread box */}
              <div className="flex-grow my-3 overflow-y-auto space-y-2.5 pr-1 max-h-56">
                {chatMessages.map((msg, idx) => (
                  <div 
                    key={idx} 
                    className={`flex flex-col text-xs max-w-[85%] ${msg.sender === 'user' ? 'ml-auto text-right items-end' : msg.sender === 'system' ? 'mx-auto text-center items-center' : 'mr-auto text-left items-start'}`}
                  >
                    <div 
                      className={`p-2.5 rounded-2xl leading-normal ${msg.sender === 'user' ? 'bg-[#ff5c3e] text-white rounded-tr-none' : msg.sender === 'system' ? 'bg-gray-100 text-gray-500 italic text-[10px]' : 'bg-gray-50 border border-gray-200 text-[#271810] rounded-tl-none'}`}
                    >
                      {msg.text}
                    </div>
                    <span className="text-[8px] text-gray-400 font-mono mt-0.5">{msg.time}</span>
                  </div>
                ))}
              </div>

              {/* Chat Input area */}
              <div className="space-y-2 pt-2 border-t border-gray-100">
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    placeholder="Ask Alex: 'Fresh?', 'Slow?', etc."
                    value={typedMessage}
                    onChange={(e) => setTypedMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSendChatMessage();
                    }}
                    className="w-full bg-[#fdfaf8] border border-gray-200 text-xs py-2 px-3 rounded-xl focus:outline-none focus:border-[#ff5c3e] font-medium"
                  />
                  
                  <button
                    type="button"
                    onClick={handleSendChatMessage}
                    className="bg-primary hover:bg-primary-container text-white p-2.5 rounded-xl flex items-center justify-center cursor-pointer shrink-0"
                  >
                    <span className="material-symbols-outlined text-[16px] block">send</span>
                  </button>
                </div>
                <div className="flex gap-1.5 justify-center">
                  <button onClick={() => { setTypedMessage("Is crop load verified organic?"); }} className="text-[8.5px] bg-gray-100 hover:bg-gray-200 hover:text-black py-1 px-2 rounded-lg text-gray-500 font-bold">Query Organic Status</button>
                  <button onClick={() => { setTypedMessage("Where are you on the map?"); }} className="text-[8.5px] bg-gray-100 hover:bg-gray-200 hover:text-black py-1 px-2 rounded-lg text-gray-500 font-bold">Query Map ETA</button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* COURIER DIALER CALL POPUP SYSTEM */}
      {isCalling && (
        <div className="fixed bottom-6 left-6 bg-[#271810] border-2 border-[#ff5c3e] text-white p-4 rounded-3xl max-w-sm w-80 space-y-4 shadow-2xl z-50 animate-fade-in text-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center animate-pulse">
              <span className="material-symbols-outlined text-white">call</span>
            </div>
            <div className="text-left font-mono">
              <p className="text-[10px] text-gray-400 uppercase font-bold">Zenvego Voice Service</p>
              <h4 className="text-sm font-black">Alex River • Rider</h4>
              <p className="text-[10px] text-emerald-400">Dialing voice node tunnel...</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsCalling(false)}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-extrabold py-2 rounded-xl text-xs"
          >
            End Cellular Connection
          </button>
        </div>
      )}

    </div>
  );
}
