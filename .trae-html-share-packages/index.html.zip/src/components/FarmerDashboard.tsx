import React, { useState } from 'react';
import { ViewState, LoggedInUser } from '../types';
import { Currency, formatPrice } from '../utils/currency';
import CurrencySelector from './CurrencySelector';
import { handleImageError } from '../utils/imageFallback';
import { downloadSellHistoryPdf, downloadSellHistoryExcel } from '../lib/exportDocs';
import { startScanner, stopScanner, isScannerSupported } from '../lib/qrScanner';
import { captureFromCamera, readFileAsDataUrl } from '../lib/photo';

interface FarmerDashboardProps {
  setView: (view: ViewState) => void;
  addToast: (msg: string) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  sessionUser?: LoggedInUser | null;
  handleLogout?: () => void;
}

export default function FarmerDashboard({ 
  setView, 
  addToast, 
  currency, 
  setCurrency,
  sessionUser,
  handleLogout
}: FarmerDashboardProps) {
  const [selectedRange, setSelectedRange] = useState('weekly');
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [selfiePhoto, setSelfiePhoto] = useState('');
  const [scanResult, setScanResult] = useState('');

  const handleCaptureSelfie = async () => {
    try {
      const dataUrl = await captureFromCamera();
      setSelfiePhoto(dataUrl);
      addToast('Selfie captured.');
    } catch {
      addToast('Camera not available. Please upload a photo.');
    }
  };

  const handleUploadSelfie = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await readFileAsDataUrl(file);
    setSelfiePhoto(dataUrl);
    addToast('Photo uploaded.');
  };

  const handleExportPdf = () => {
    const orders = incomingpreorders.map((t, i) => ({
      id: `TXN-${i}`,
      orderNo: t.id,
      customerId: 'cust',
      customerName: t.consumer,
      items: [{ productId: 'p', name: t.item, price: t.payout, quantity: parseInt(t.qty) || 1, unit: t.qty, farm: 'Sunny Hills' }],
      total: t.payout,
      currency: currency,
      status: 'delivered',
      address: '',
      paymentMethod: 'upi' as const,
      createdAt: Date.now() - i * 3600000,
      updatedAt: Date.now(),
    }));
    downloadSellHistoryPdf(orders, sessionUser?.name || 'Seller');
    addToast('Sell history PDF downloaded.');
  };

  const handleExportExcel = () => {
    const orders = incomingpreorders.map((t, i) => ({
      id: `TXN-${i}`,
      orderNo: t.id,
      customerId: 'cust',
      customerName: t.consumer,
      items: [{ productId: 'p', name: t.item, price: t.payout, quantity: parseInt(t.qty) || 1, unit: t.qty, farm: 'Sunny Hills' }],
      total: t.payout,
      currency: currency,
      status: 'delivered',
      address: '',
      paymentMethod: 'upi' as const,
      createdAt: Date.now() - i * 3600000,
      updatedAt: Date.now(),
    }));
    downloadSellHistoryExcel(orders, sessionUser?.name || 'Seller');
    addToast('Sell history Excel downloaded.');
  };

  const startQrScan = async () => {
    if (!isScannerSupported()) {
      addToast('Camera scanner not supported on this device.');
      return;
    }
    try {
      await startScanner('qr-reader', (text) => {
        setScanResult(text);
        stopScanner();
        addToast(`QR scanned: ${text}`);
      });
    } catch {
      addToast('Failed to start camera scanner.');
    }
  };

  const salesHistory = [
    { day: "Mon", sales: 120, preorders: 34 },
    { day: "Tue", sales: 180, preorders: 45 },
    { day: "Wed", sales: 240, preorders: 60 },
    { day: "Thu", sales: 190, preorders: 52 },
    { day: "Fri", sales: 310, preorders: 84 },
    { day: "Sat", sales: 420, preorders: 110 },
    { day: "Sun", sales: 380, preorders: 95 }
  ];

  const incomingpreorders = [
    { id: "TXN-09", consumer: "Sarah Jenkins", item: "Organic Vine Heirloom Tomatoes", qty: "3 lbs", payout: 14.40, time: "18m ago" },
    { id: "TXN-08", consumer: "Sarah Jenkins", item: "Rainbow Heirloom Carrots Bunch", qty: "1 bunch", payout: 3.50, time: "42m ago" },
    { id: "TXN-05", consumer: "David Kim", item: "Organic Vine Heirloom Tomatoes", qty: "2 lbs", payout: 9.60, time: "2h ago" },
    { id: "TXN-02", consumer: "Emily Parker", item: "Glossy Farmer Purple Brinjals", qty: "4 lbs", payout: 15.60, time: "4h ago" }
  ];

  const overallFeedback = [
    { score: "5/5", text: "Stunning tomato sweetness, completely clean and free of spots. Love Sunny Hills!", author: "Sarah J." },
    { score: "4.8/5", text: "Very sweet rainbow carrots. Delivered promptly to community lockers.", author: "Michael B." }
  ];

  const triggerExport = () => {
    addToast("Exporting express courier dispatch manifest .CSV to your Local Sourcing Device...");
  };

  // Matching QR handoff scanner states
  const [showHandoffModal, setShowHandoffModal] = useState(false);
  const [verificationInput, setVerificationInput] = useState('');
  
  const handleApproveHandover = () => {
    const cleanInput = verificationInput.trim().toUpperCase();
    if (cleanInput === '7749' || cleanInput.includes('7749') || cleanInput.includes('ZEN-RELEASE-7749')) {
      // Synchronize back to the active delivery job
      const activeJobRaw = localStorage.getItem('zenvego_active_delivery_job');
      if (activeJobRaw) {
        try {
          const parsed = JSON.parse(activeJobRaw);
          parsed.status = "Transit"; // This triggers the courier screen to shift coordinates!
          localStorage.setItem('zenvego_active_delivery_job', JSON.stringify(parsed));
        } catch(e) {}
      }
      addToast("✅ QR SCAN MATCHED: Courier identification verified! Sourcing cargo safely released.");
      setShowHandoffModal(false);
    } else {
      addToast("❌ Code Verification Mismatch. Ensure the Driver displays their correct autogen security QR.");
    }
  };

  const autofillScanCode = () => {
    // Autoload live code from storage for beautiful zero friction simulation
    const codeFromStorage = localStorage.getItem('zenvego_active_verification_code') || 'ZEN-RELEASE-7749';
    setVerificationInput(codeFromStorage);
    addToast("📷 Camera Optical Sweep Simulated: Scanned Courier QR Code successfully!");
  };

  return (
    <div id="farmer-dash-container" className="min-h-screen bg-[#fff8f6] flex flex-col font-sans">
      
      {/* Header bar */}
      <header className="bg-white border-b border-surface-container py-3.5 px-4 md:px-8 sticky top-0 z-40 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img 
            src={sessionUser?.avatar || "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200"} 
            alt={sessionUser?.name || "John Miller"} 
            referrerPolicy="no-referrer"
            onError={(e) => handleImageError(e, 'avatar')}
            className="w-10 h-10 rounded-full border border-primary/20 object-cover" 
          />
          <div>
            <div className="flex items-center gap-1">
              <h1 className="text-sm font-extrabold text-[#271810]">
                {sessionUser ? sessionUser.name : "John Miller"} / Sunny Hills Organic
              </h1>
              <span className="material-symbols-outlined text-[14px] text-primary fill-icon" title="Verified Harvester">verified</span>
            </div>
            <p className="text-[10px] text-outline uppercase font-semibold">
              {sessionUser ? `Welcome, ${sessionUser.name}` : "Decentralized Harvester Ledger Portal"}
            </p>
          </div>
        </div>

        {/* Header CTA Switcher */}
        <div className="flex items-center gap-2">
          <CurrencySelector currency={currency} setCurrency={setCurrency} />
          
          <button 
            onClick={() => setView('farmer-inventory')}
            className="bg-surface-container hover:bg-surface-container-highest text-primary font-bold text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">inventory_2</span>
            Inventory Management
          </button>
          
          <button 
            onClick={() => {
              if (handleLogout) {
                handleLogout();
              }
              setView('market-home');
            }}
            className="hover:bg-surface-container text-outline font-bold text-xs px-2.5 py-2 rounded-xl transition-all cursor-pointer"
          >
            Logout
          </button>
        </div>
      </header>

      {/* Main Grid content */}
      <main className="flex-grow p-4 md:p-8 max-w-7xl mx-auto w-full space-y-6">
        
        {/* Metric Cards top row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-surface-container shadow-sm space-y-1">
            <span className="text-[10px] uppercase font-bold text-outline">Express Deliveries Value</span>
            <p className="text-2xl font-black text-primary">{formatPrice(1830.00, currency)}</p>
            <span className="text-[10px] text-green-700 font-semibold flex items-center gap-0.5">
              <span className="material-symbols-outlined text-[10px] font-bold">trending_up</span>
              +14% vs last drop
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-surface-container shadow-sm space-y-1">
            <span className="text-[10px] uppercase font-bold text-outline">Ecosystem Rating</span>
            <p className="text-2xl font-black text-on-surface flex items-center gap-1">
              4.92 <span className="material-symbols-outlined text-secondary text-[20px] fill-icon">star</span>
            </p>
            <span className="text-[10px] text-outline">Based on 142 voter ledger marks</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-surface-container shadow-sm space-y-1">
            <span className="text-[10px] uppercase font-bold text-outline">Active Reserves Capacity</span>
            <p className="text-2xl font-black text-secondary">82% Locked</p>
            <span className="text-[10px] text-primary font-semibold">14 bunches remaining</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-surface-container shadow-sm space-y-1">
            <span className="text-[10px] uppercase font-bold text-outline">Verification Status</span>
            <p className="text-2xl font-black text-[#0c6b41]">
              {sessionUser?.idVerified ? 'Verified' : 'Pending'}
            </p>
            <button
              onClick={() => setShowPhotoModal(true)}
              className="text-[10px] text-primary font-semibold hover:underline"
            >
              {sessionUser?.idVerified ? 'Update Photo ID' : 'Complete Photo Verification'}
            </button>
          </div>
        </div>

        {/* Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Sales Performance Chart */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-surface-container space-y-4 shadow-sm">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <div>
                <h3 className="font-extrabold text-on-surface text-base flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-primary">analytics</span>
                  Historical Community Express Order Volumes
                </h3>
                <p className="text-xs text-on-surface-variant">Real-time local ledger checkins</p>
              </div>

              {/* Time Range Selector */}
              <div className="flex items-center gap-1 bg-surface-container p-1 rounded-xl">
                <button 
                  onClick={() => setSelectedRange('weekly')} 
                  className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all ${selectedRange === 'weekly' ? 'bg-white text-primary shadow-sm' : 'text-outline hover:text-on-surface'}`}
                >
                  Weekly
                </button>
                <button 
                  onClick={() => setSelectedRange('monthly')} 
                  className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all ${selectedRange === 'monthly' ? 'bg-white text-primary shadow-sm' : 'text-outline hover:text-on-surface'}`}
                >
                  Monthly
                </button>
              </div>
            </div>

            {/* Custom SVG High-Fidelity Chart */}
            <div className="pt-4">
              <div className="relative h-64 w-full flex items-end justify-between gap-2.5 pt-6 border-b border-surface-container-high px-2 pb-1 bg-[#fffdfc] rounded-2xl border border-surface-container-low">
                {/* Horizontal guide lines */}
                <div className="absolute left-0 right-0 top-1/4 border-b border-dashed border-surface-container-low/85"></div>
                <div className="absolute left-0 right-0 top-2/4 border-b border-dashed border-surface-container-low/85"></div>
                <div className="absolute left-0 right-0 top-3/4 border-b border-dashed border-surface-container-low/85"></div>

                {salesHistory.map((item, idx) => {
                  const barHeightPercent = (item.sales / 450) * 100;
                  const preorderHeightPercent = (item.preorders / 120) * 100;

                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center group relative z-10">
                      {/* Interactive Tooltip Card */}
                      <div className="absolute bottom-full mb-2 bg-[#271810] text-white text-[10px] p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl border border-white/10 text-center pointer-events-none">
                        <p className="font-bold">{item.day} Sells</p>
                        <p className="text-primary font-bold">Total: ${item.sales}</p>
                        <p className="text-[#a24000] font-bold">Reserves: {item.preorders}</p>
                      </div>

                      {/* Stacked Graphic columns */}
                      <div className="w-full max-w-[28px] rounded-t-lg bg-primary/10 hover:bg-primary/20 transition-colors h-48 flex items-end gap-[2px] justify-center overflow-hidden">
                        <div 
                          style={{ height: `${preorderHeightPercent}%` }} 
                          className="w-[8px] bg-secondary rounded-t"
                          title="Preorders limit"
                        ></div>
                        <div 
                          style={{ height: `${barHeightPercent}%` }} 
                          className="w-[12px] bg-primary rounded-t"
                          title="Sales volume"
                        ></div>
                      </div>

                      <span className="text-[10px] font-bold text-outline mt-2 block">{item.day}</span>
                    </div>
                  );
                })}
              </div>

              {/* Chart Legend */}
              <div className="flex justify-center gap-6 pt-4 text-xs font-semibold">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-primary rounded"></span>
                  <span className="text-on-surface-variant">General Market Purchases ($)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 bg-secondary rounded"></span>
                  <span className="text-on-surface-variant">Express Delivery Orders</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Incoming Purchases list & Customer feedback */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Real-time deliveries dispatch list */}
            <div className="bg-white rounded-3xl p-6 border border-surface-container space-y-4 shadow-sm">
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-on-surface text-sm flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-primary">bookmark_manager</span>
                  Express Dispatch List
                </h3>
                
                <div className="flex gap-1.5">
                  <button
                    onClick={handleExportPdf}
                    className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-1 rounded hover:bg-primary/10 transition-colors"
                  >
                    Export PDF
                  </button>
                  <button
                    onClick={handleExportExcel}
                    className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-1 rounded hover:bg-primary/10 transition-colors"
                  >
                    Export Excel
                  </button>
                </div>
              </div>

              <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                {incomingpreorders.map((txn, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high space-y-1 text-xs">
                    <div className="flex justify-between font-bold">
                      <span className="text-on-surface">{txn.consumer}</span>
                      <span className="text-primary">{formatPrice(txn.payout, currency)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-on-surface-variant">
                      <span>{txn.qty} x {txn.item.replace('Organic ', '').replace('Heirloom ', '')}</span>
                      <span className="text-outline font-mono">{txn.time}</span>
                    </div>
                    <div className="pt-1 select-none flex items-center gap-1 text-[9px] text-outline">
                      <span className="material-symbols-outlined text-[10px]">framer_credential</span>
                      <span>Verified ledger ID: {txn.id}</span>
                    </div>

                    {/* Integrated scanning dispatch trigger */}
                    {txn.id === 'TXN-09' && (
                      <div className="pt-2 border-t border-surface-container mt-1.5 flex justify-between items-center bg-primary/5 p-1.5 rounded-lg">
                        <span className="text-[10px] text-primary italic font-bold">Alex River (#ZVG-902)</span>
                        <button
                          type="button"
                          onClick={() => setShowHandoffModal(true)}
                          className="bg-primary hover:bg-primary-hover text-white font-black text-[9px] px-2 py-1 rounded flex items-center gap-1 cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[11px]">qr_code_scanner</span>
                          Scan Code
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Live customer testimonials */}
            <div className="bg-white rounded-3xl p-6 border border-surface-container space-y-3 shadow-sm">
              <h4 className="font-bold text-on-surface text-sm flex items-center gap-1.5">
                <span className="material-symbols-outlined text-secondary fill-icon">volunteer_activism</span>
                Community trust ratings
              </h4>

              <div className="space-y-2.5 divide-y divide-surface-container">
                {overallFeedback.map((comment, idx) => (
                  <div key={idx} className="pt-2.5 first:pt-0 space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-bold text-primary">{comment.author}</span>
                      <span className="bg-secondary/15 text-secondary px-1.5 py-0.5 rounded text-[9px] font-extrabold flex items-center gap-0.5">
                        {comment.score} <span className="material-symbols-outlined text-[9px] fill-icon">star</span>
                      </span>
                    </div>
                    <p className="text-[11px] italic text-[#271810]/80">"{comment.text}"</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </main>

      {/* HARVEST HANDOVER QR CODES SCANNERS SYSTEM */}
      {showHandoffModal && (
        <div className="fixed inset-0 bg-[#271810]/75 backdrop-blur-md flex items-center justify-center p-4 z-50 text-center animate-fade-in text-surface">
          <div className="bg-white border-2 border-primary/20 text-[#271810] rounded-3xl p-6 md:p-8 max-w-sm w-full space-y-6 shadow-2xl relative">
            <button
              type="button"
              onClick={() => setShowHandoffModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 outline-none text-sm font-bold"
            >
              ✕
            </button>

            <div className="space-y-1">
              <span className="bg-primary/10 text-primary text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-primary/25">
                Harvest Code Handoff Matrix
              </span>
              <h4 className="text-base font-serif font-black text-[#271810] pt-1">Verify Rider Alex River (#902)</h4>
              <p className="text-[11px] text-[#271810]/70">Confirm rider holds valid autogen release PIN and that payload is routed to Sarah Jenkins.</p>
            </div>

            {/* Real Camera QR Scanner */}
            <div className="relative border-4 border-dashed border-primary rounded-2xl p-4 bg-gray-50 h-48 flex flex-col justify-center items-center overflow-hidden">
              <div id="qr-reader" className="w-full h-full"></div>
              {!scanResult && (
                <>
                  <span className="material-symbols-outlined text-[48px] text-primary block animate-pulse">qr_code_scanner</span>
                  <p className="text-[9px] text-[#271810]/60 font-mono tracking-wider uppercase mt-2">Point camera at QR code</p>
                </>
              )}
              {scanResult && (
                <div className="absolute inset-0 bg-[#eefcf4]/90 flex flex-col justify-center items-center p-2 text-center">
                  <span className="material-symbols-outlined text-emerald-600 text-[28px]">verified</span>
                  <span className="text-[10px] uppercase font-bold text-emerald-800 font-mono tracking-wide mt-1">SCAN SUCCESSFUL</span>
                  <span className="text-xs font-black font-mono mt-0.5 text-[#271810] break-all">{scanResult}</span>
                </div>
              )}
            </div>

            <div className="space-y-3.5 text-xs font-medium">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={startQrScan}
                  className="w-full bg-[#271810] text-[#ffede5] font-extrabold py-2 rounded-xl text-[10.5px] transition-all hover:bg-[#1c110a] flex items-center justify-center gap-1.5"
                >
                  <span className="material-symbols-outlined text-[14px]">scanner</span>
                  Start Camera Scan
                </button>
              </div>

              <div className="space-y-1 text-left pt-1 font-mono">
                <label className="text-[10px] text-gray-500 uppercase block font-semibold">Or Enter Verification Code:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter code from QR"
                    value={verificationInput}
                    onChange={(e) => setVerificationInput(e.target.value)}
                    className="w-full bg-[#fffcfb] border border-gray-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:border-primary text-center font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleApproveHandover}
                    className="bg-primary hover:bg-primary-hover text-white font-extrabold px-4.5 rounded-lg text-xs"
                  >
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PHOTO VERIFICATION MODAL */}
      {showPhotoModal && (
        <div className="fixed inset-0 bg-[#271810]/75 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 relative">
            <button
              onClick={() => setShowPhotoModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-sm font-bold"
            >
              ✕
            </button>
            <h3 className="text-base font-black text-[#271810]">Photo Verification</h3>
            <p className="text-xs text-gray-500">Take a selfie or upload a clear photo of your face for identity verification.</p>
            {selfiePhoto ? (
              <img src={selfiePhoto} alt="Verification" className="w-40 h-40 object-cover rounded-2xl mx-auto" />
            ) : (
              <div className="w-40 h-40 bg-gray-100 rounded-2xl mx-auto flex items-center justify-center">
                <span className="material-symbols-outlined text-gray-400 text-[48px]">person</span>
              </div>
            )}
            <div className="flex gap-2 justify-center">
              <button
                onClick={handleCaptureSelfie}
                className="bg-primary text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-primary-hover"
              >
                Take Selfie
              </button>
              <label className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-xs font-bold hover:bg-gray-200 cursor-pointer">
                Upload
                <input type="file" accept="image/*" onChange={handleUploadSelfie} className="hidden" />
              </label>
            </div>
            {selfiePhoto && (
              <button
                onClick={() => {
                  setShowPhotoModal(false);
                  addToast('Photo verification submitted.');
                }}
                className="w-full bg-emerald-600 text-white py-2.5 rounded-xl text-sm font-bold"
              >
                Submit Verification
              </button>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
