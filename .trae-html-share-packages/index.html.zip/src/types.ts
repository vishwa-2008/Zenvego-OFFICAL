export type ViewState =
  | 'market-home'
  | 'buyer-marketplace'
  | 'checkout'
  | 'buyer-account'
  | 'farmer-dashboard'
  | 'farmer-inventory'
  | 'delivery-dashboard'
  | 'delivery-route'
  | 'login'
  | 'registration-onboarding';

export type Role = 'customer' | 'seller' | 'delivery';

export interface LoggedInUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
  idVerified?: boolean;
  selfiePhoto?: string;
  profileData?: Record<string, any>;
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  unit: string;
  farm: string;
  image: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  qty: number;
  unit: string;
  category: string;
  image: string;
  farm: string;
  farmer: string;
  desc: string;
  organic: boolean;
  boosted: boolean;
  origin?: string;
}

export interface Farmer {
  id: string;
  name: string;
  avatar: string;
  banner: string;
  verified: boolean;
  type: string;
  drop: string;
}
