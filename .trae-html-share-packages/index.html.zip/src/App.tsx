import React, { useState, useEffect, useCallback } from 'react';
import { ViewState, CartItem, LoggedInUser, Product } from './types';
import { Currency } from './utils/currency';
import FarmersMarketHome from './components/FarmersMarketHome';
import BuyerMarketplace from './components/BuyerMarketplace';
import CheckoutView from './components/CheckoutView';
import MyAccountView from './components/MyAccountView';
import FarmerDashboard from './components/FarmerDashboard';
import FarmerInventory from './components/FarmerInventory';
import DeliveryDashboard from './components/DeliveryDashboard';
import DeliveryActiveRoute from './components/DeliveryActiveRoute';
import LoginView from './components/LoginView';
import RegistrationOnboarding from './components/RegistrationOnboarding';
import { getCurrentSession, logout as authLogout } from './lib/auth';
import {
  getAllProducts,
  putProduct,
  generateId,
  type ProductRecord,
} from './lib/db';

interface Toast {
  id: string;
  message: string;
}

const SEED_PRODUCTS: ProductRecord[] = [
  {
    id: 'prod-tomato',
    name: 'Organic Vine Heirloom Tomatoes',
    price: 4.8,
    unit: 'lb',
    category: 'Vegetables',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=400',
    farm: 'Sunny Hills Organic',
    farmerId: 'farmer-john',
    farmerName: 'John Miller',
    qty: 24,
    origin: 'Field Block A',
    organic: true,
    desc: 'Crimson, succulent vine heirloom tomatoes harvested at dawn. Unmatched sweetness.',
    createdAt: Date.now(),
  },
  {
    id: 'prod-carrot',
    name: 'Rainbow Heirloom Carrots Bunch',
    price: 3.5,
    unit: 'bunch',
    category: 'Roots',
    image: 'https://images.unsplash.com/photo-1444312645910-ffa973656eba?auto=format&fit=crop&q=80&w=400',
    farm: 'Sunny Hills Organic',
    farmerId: 'farmer-john',
    farmerName: 'John Miller',
    qty: 15,
    origin: 'Greenhouse B',
    organic: true,
    desc: 'Beautiful hues of purple, orange, and pale yellow roots. Clean and crunchy.',
    createdAt: Date.now(),
  },
  {
    id: 'prod-kale',
    name: 'Earthy Mountain Dinosaur Kale',
    price: 2.9,
    unit: 'bunch',
    category: 'Vegetables',
    image: 'https://images.unsplash.com/photo-1524179091875-bf99a9a6af57?auto=format&fit=crop&q=80&w=400',
    farm: 'Green Peak Growers',
    farmerId: 'farmer-sarah',
    farmerName: "Sarah's Favorites",
    qty: 18,
    origin: 'Highland Ridge',
    organic: true,
    desc: 'Rich dark green Tuscan cavolo nero kale. Packed with iron, freshly harvested.',
    createdAt: Date.now(),
  },
  {
    id: 'prod-eggplant',
    name: 'Glossy Farmer Purple Brinjals',
    price: 3.9,
    unit: 'lb',
    category: 'Vegetables',
    image: 'https://images.unsplash.com/photo-1528137871618-79d2761e38c2?auto=format&fit=crop&q=80&w=400',
    farm: 'Sunny Hills Organic',
    farmerId: 'farmer-john',
    farmerName: 'John Miller',
    qty: 12,
    origin: 'Field Block F',
    organic: true,
    desc: 'Firm, premium dark skins, mild internal flesh. Baked wonders.',
    createdAt: Date.now(),
  },
  {
    id: 'prod-honey',
    name: 'Wildflower Pure Raw Comb Honey',
    price: 8.5,
    unit: 'jar',
    category: 'Sweets & Honey',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=400',
    farm: 'Wildflower Honey Farm',
    farmerId: 'farmer-robert',
    farmerName: 'Robert Beekeeper',
    qty: 20,
    origin: 'Forest Nest Beta',
    organic: true,
    desc: 'Raw nectar sourced straight from forest wildflower canopies. Naturally sweet.',
    createdAt: Date.now(),
  },
];

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('market-home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [showConsole, setShowConsole] = useState(false); // hidden by default
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');

  // Real session user from IndexedDB auth
  const [sessionUser, setSessionUser] = useState<LoggedInUser | null>(null);
  const [authReady, setAuthReady] = useState(false);

  const [preselectedRole, setPreselectedRole] = useState<'customer' | 'seller' | 'delivery' | null>(null);

  const [measurementSystem, setMeasurementSystemState] = useState<'US' | 'IND'>(() => {
    const cached = localStorage.getItem('zenvego_measurement_system');
    return cached === 'IND' || cached === 'US' ? (cached as 'US' | 'IND') : 'US';
  });

  const [currency, setCurrencyState] = useState<Currency>(() => {
    const cached = localStorage.getItem('zenvego_currency');
    if (cached === 'INR' || cached === 'USD') return cached as Currency;
    return 'USD';
  });

  // Master product catalog from IndexedDB
  const [products, setProducts] = useState<Product[]>([]);

  // Load session + seed products on mount
  useEffect(() => {
    (async () => {
      const user = await getCurrentSession();
      if (user) {
        setSessionUser({
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          idVerified: user.idVerified,
          selfiePhoto: user.selfiePhoto,
        });
      }
      setAuthReady(true);

      // Seed products if IndexedDB is empty
      const existing = await getAllProducts();
      if (existing.length === 0) {
        for (const p of SEED_PRODUCTS) {
          await putProduct(p);
        }
        setProducts(SEED_PRODUCTS.map(mapProduct));
      } else {
        setProducts(existing.map(mapProduct));
      }
    })();
  }, []);

  const mapProduct = (p: ProductRecord): Product => ({
    id: p.id,
    name: p.name,
    price: p.price,
    qty: p.qty,
    unit: p.unit,
    category: p.category,
    image: p.image,
    farm: p.farm,
    farmer: p.farmerName,
    desc: p.desc,
    organic: p.organic,
    boosted: false,
    origin: p.origin,
  });

  const setMeasurementSystem = (system: 'US' | 'IND') => {
    setMeasurementSystemState(system);
    localStorage.setItem('zenvego_measurement_system', system);
    if (system === 'IND') {
      setCurrencyState('INR');
      localStorage.setItem('zenvego_currency', 'INR');
    } else {
      setCurrencyState('USD');
      localStorage.setItem('zenvego_currency', 'USD');
    }
    addToast(`Region mode: measuring units updated to ${system === 'IND' ? 'Metric (kg, km)' : 'U.S. (lbs, miles)'}`);
  };

  const handleLogout = async () => {
    await authLogout();
    setSessionUser(null);
    setCurrentView('market-home');
    addToast('Logged out. Thank you for supporting local growers!');
  };

  const handleLoginSuccess = (user: LoggedInUser) => {
    setSessionUser(user);
    setPreselectedRole(null);
    addToast('Authorized! Proceeding to registration onboarding...');
    setCurrentView('registration-onboarding');
  };

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency);
    localStorage.setItem('zenvego_currency', newCurrency);
    addToast(`Price reference in ${newCurrency === 'INR' ? 'Indian Rupee (INR)' : 'U.S. Dollar (USD)'}`);
  };

  const addToast = useCallback((message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setToasts((prev) => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const addToCart = (product: any) => {
    const masterProd = products.find((p) => p.id === product.id);
    if (!masterProd) {
      addToast('Error: Item not found in live harvest database.');
      return;
    }
    setCart((prev) => {
      const idx = prev.findIndex((item) => item.id === product.id);
      if (idx !== -1) {
        if (prev[idx].quantity >= masterProd.qty) {
          addToast(`Out of stock! Cannot reserve more than ${masterProd.qty} ${product.unit}.`);
          return prev;
        }
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + 1 };
        addToast(`Incremented reserve: ${product.name} (Qty ${copy[idx].quantity})`);
        return copy;
      }
      if (masterProd.qty <= 0) {
        addToast(`${product.name} is currently out of stock!`);
        return prev;
      }
      addToast(`Reserved: ${product.name} added to harvest list!`);
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          unit: product.unit,
          farm: product.farm,
          image: product.image,
        },
      ];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => {
      const item = prev.find((i) => i.id === itemId);
      if (!item) return prev;
      if (item.quantity > 1) {
        const copy = [...prev];
        const idx = copy.findIndex((i) => i.id === itemId);
        copy[idx] = { ...copy[idx], quantity: copy[idx].quantity - 1 };
        addToast(`Decremented reserve: ${item.name} (Qty ${copy[idx].quantity})`);
        return copy;
      }
      addToast(`Removed ${item.name} from your express delivery basket.`);
      return prev.filter((i) => i.id !== itemId);
    });
  };

  const clearCart = () => {
    setCart([]);
    addToast('Express delivery basket emptied.');
  };

  const handleCheckoutSuccess = () => {
    setProducts((prev) =>
      prev.map((p) => {
        const cartItem = cart.find((item) => item.id === p.id);
        if (cartItem) {
          return { ...p, qty: Math.max(0, p.qty - cartItem.quantity) };
        }
        return p;
      })
    );
    setCart([]);
  };

  // Guard routing
  useEffect(() => {
    if (!authReady) return;
    const protectedViews: ViewState[] = [
      'buyer-marketplace',
      'checkout',
      'buyer-account',
      'farmer-dashboard',
      'farmer-inventory',
      'delivery-dashboard',
      'delivery-route',
      'registration-onboarding',
    ];
    if (protectedViews.includes(currentView) && !sessionUser) {
      addToast('Unauthorized access. Please log in to proceed.');
      setCurrentView('login');
    }
  }, [currentView, sessionUser, authReady, addToast]);

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fff8f6]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#0f5238] border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-background selection:bg-primary/25 selection:text-primary font-sans">
      <main className="transition-all duration-300">
        {currentView === 'market-home' && (
          <FarmersMarketHome
            setView={setCurrentView}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            setPreselectedRole={setPreselectedRole}
            globalSearchTerm={globalSearchTerm}
            setGlobalSearchTerm={setGlobalSearchTerm}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'buyer-marketplace' && (
          <BuyerMarketplace
            setView={setCurrentView}
            cart={cart}
            addToCart={addToCart}
            removeFromCart={removeFromCart}
            clearCart={clearCart}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            globalSearchTerm={globalSearchTerm}
            setGlobalSearchTerm={setGlobalSearchTerm}
            products={products}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'checkout' && (
          <CheckoutView
            setView={setCurrentView}
            cart={cart}
            clearCart={clearCart}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            onCheckoutSuccess={handleCheckoutSuccess}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'buyer-account' && (
          <MyAccountView
            setView={setCurrentView}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'farmer-dashboard' && (
          <FarmerDashboard
            setView={setCurrentView}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'farmer-inventory' && (
          <FarmerInventory
            setView={setCurrentView}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            products={products}
            setProducts={setProducts}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'delivery-dashboard' && (
          <DeliveryDashboard
            setView={setCurrentView}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'delivery-route' && (
          <DeliveryActiveRoute
            setView={setCurrentView}
            addToast={addToast}
            currency={currency}
            setCurrency={setCurrency}
            sessionUser={sessionUser}
            handleLogout={handleLogout}
            measurementSystem={measurementSystem}
          />
        )}
        {currentView === 'login' && (
          <LoginView
            setView={setCurrentView}
            addToast={addToast}
            preselectedRole={preselectedRole}
            setPreselectedRole={setPreselectedRole}
            onLoginSuccess={handleLoginSuccess}
          />
        )}
        {currentView === 'registration-onboarding' && (
          <RegistrationOnboarding
            setView={setCurrentView}
            sessionUser={sessionUser}
            setSessionUser={setSessionUser}
            addToast={addToast}
            measurementSystem={measurementSystem}
          />
        )}
      </main>

      {/* Toast notifications */}
      <div className="fixed bottom-6 right-6 z-50 space-y-2 pointer-events-none max-w-sm w-full">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="p-4 rounded-2xl bg-[#271810] text-[#fff8f6] text-xs font-semibold shadow-2xl flex items-center gap-2.5 border border-white/5 animate-fade-in pointer-events-auto"
          >
            <span className="material-symbols-outlined text-secondary fill-icon">notifications_active</span>
            <p>{toast.message}</p>
          </div>
        ))}
      </div>

      {/* Console toggle button (small, hidden panel by default) */}
      {!showConsole && (
        <button
          onClick={() => setShowConsole(true)}
          className="fixed top-4 right-4 z-[9998] p-2 bg-[#271810]/80 text-white rounded-full border border-white/10 shadow-lg hover:scale-105 transition-all"
          title="Open developer console"
        >
          <span className="material-symbols-outlined text-[18px]">menu_open</span>
        </button>
      )}

      {/* Console panel (currency + view switcher) */}
      {showConsole && (
        <div className="fixed top-4 right-4 z-[9999] w-64 bg-[#271810]/95 backdrop-blur-md rounded-2xl border border-white/10 p-4 space-y-3 shadow-2xl text-white">
          <div className="flex justify-between items-center pb-2 border-b border-white/10">
            <span className="text-xs font-extrabold tracking-widest uppercase">Zenvego Console</span>
            <button onClick={() => setShowConsole(false)} className="text-white hover:text-secondary">
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
          <div className="space-y-1.5 pb-2 border-b border-white/10">
            <p className="text-[9px] uppercase tracking-wider text-outline-variant font-bold">Region & Currency</p>
            <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
              <span className="text-[10px] text-white/80 font-bold">Region:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => setMeasurementSystem('US')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold ${measurementSystem === 'US' ? 'bg-green-600 text-white' : 'bg-white/15'}`}
                >
                  US
                </button>
                <button
                  onClick={() => setMeasurementSystem('IND')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold ${measurementSystem === 'IND' ? 'bg-green-600 text-white' : 'bg-white/15'}`}
                >
                  IND
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
              <span className="text-[10px] text-white/80 font-bold">Currency:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => setCurrency('USD')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold ${currency === 'USD' ? 'bg-[#ff5c3e] text-white' : 'bg-white/15'}`}
                >
                  USD
                </button>
                <button
                  onClick={() => setCurrency('INR')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold ${currency === 'INR' ? 'bg-[#ff5c3e] text-white' : 'bg-white/15'}`}
                >
                  INR
                </button>
              </div>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-[9px] uppercase tracking-wider text-outline-variant font-bold">Quick Navigate</p>
            <div className="grid grid-cols-2 gap-1 text-[10px]">
              {([
                ['market-home', 'Landing'],
                ['buyer-marketplace', 'Market'],
                ['checkout', 'Checkout'],
                ['buyer-account', 'Profile'],
                ['farmer-dashboard', 'Farmer'],
                ['farmer-inventory', 'Stock'],
                ['delivery-dashboard', 'Courier'],
                ['delivery-route', 'Route'],
                ['login', 'Login'],
              ] as const).map(([v, label]) => (
                <button
                  key={v}
                  onClick={() => setCurrentView(v)}
                  className={`py-1 px-2 rounded-lg text-left font-bold ${
                    currentView === v ? 'bg-[#ff5c3e] text-white' : 'bg-white/5 hover:bg-white/10'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Floating Support & Care button — only visible when console is open */}
      {showConsole && (
        <button
          type="button"
          onClick={() => alert('Support: help@zenvego.org | Call: 1800-ZENVEGO\nWe are here to help 24x7.')}
          className="fixed bottom-6 left-6 z-50 p-3 bg-[#ff5c3e] text-white rounded-full border-2 border-white shadow-2xl flex items-center justify-center hover:bg-orange-600 active:scale-95 transition-all gap-1.5 font-extrabold text-xs"
          title="Customer Support"
        >
          <span className="material-symbols-outlined text-[18px]">support_agent</span>
          <span className="hidden sm:inline">Support &amp; Care</span>
        </button>
      )}
    </div>
  );
}
