# Directives for Antigravity AI Coding Agent

This document contains structural knowledge, configuration scripts, and precise directives for continuing development on **ZenVego** within the Antigravity workspace. Use this complete prompt to prime any subsequent LLM agent tool or coding assistant box to ensure it perfectly respects the existing design language, state system, and physical files.

---

## 1. System Orientation & Core Identity

- **Project Name:** ZenVego
- **Core Concept:** A hyper-local, decentralized community farmer's market network with authentic regional switcher logic, carbon emission calculations, real-time simulated order fulfillment ledgers, and audio-reactive elements.
- **Tech Stack:**
  - **Runtime & Build**: Node.js, Vite 6+, React 19, TypeScript
  - **Styling**: Tailwind CSS v4 (configured cleanly via modern `@import "tailwindcss";` directives)
  - **Animations & Micro-interactions**: `motion` (imported strictly from `motion/react`)
  - **Icons**: `lucide-react` exclusively (avoid secondary libraries, raw SVG clutter, or inline icons)

---

## 2. Strict Design Language & Web Design Guardrails

> [!WARNING]
> This codebase features highly polished, bespoke UI elements, balanced negative space, and a unified editorial/modern feel. **Do NOT redesign, alter layouts, reset fonts, or overwrite key CSS files.**

Ensure all future features strictly comply with the following styling instructions:
1. **Typography**: Always pair **Inter** (for high-contrast, professional general UI) with clean, high-contrast, deep primary accents (`#ff5c3e` coral) and earth tones (soft off-whites, warm slate, deep brown-charcoal text).
2. **Color Palette**:
   - Main Background: Deeply balanced warm cream background
   - Accent Primary: Deep tomato-red/coral (`#ff5c3e`)
   - Accent Secondary: Soft green/forest-sage green (`#1b5e20` or similar primary-container colors)
   - Accent Outline: Subtle sand borders and translucent frames
3. **Components & Layout**: 
   - Never use standard blue/purple gradient cards.
   - Retain the clean, sleek card-based styling, subtle edge-shadows, and elegant interactive states with smooth hover triggers.
   - Maintain the single-view dynamic container switching architecture present in `/src/App.tsx`. Do NOT write custom routing libraries or break the conditional view rendering.

---

## 3. Dependency & Setup Guidelines

Before making updates or additions, you must ensure the local workspace builds cleanly:
1. **Dependency Installation**:
   - Execute `npm install` strictly using Node 18+.
   - Do NOT modify `package.json` unless importing a widely-accepted library like `d3` or `recharts`. Do NOT downgrade React 19 or Vite 6.
2. **Local Dev Server Execution**:
   - Development server strictly binds to port `3000` via the script: `"dev": "vite --port=3000 --host=0.0.0.0"`. This ensures smooth container routing.

---

## 4. Key Utilities & System State

When editing components, always respect and integrate existing state-sharing utilities:
- **Currency System (`src/utils/currency.ts`)**: Supports USD ($) and INR (₹). Always format dynamic prices through:
  `formatPrice(valueInUsd, selectedCurrency)`
- **Physical & Measurement System (`src/utils/measurement.ts`)**: 
  Supports **US Customary Units** (lbs, miles) and **Indian Metric Units** (kg, km).
  - Convert weight: `convertAndFormatProductWeight(usdPrice, unit, system, currency)` or `formatWeight(lbsValue, system)`
  - Convert distance: `formatDistance(milesValue, system)`
- **Audio & Vocal Systems**: Incorporates Web-Speech-API synthesizer tools via `/src/utils/speech.ts` for automated action flows.

---

## 5. Safe Multi-File Editing Policies

- **Read-Before-Write**: Always call `view_file` to thoroughly read a component's implementation before issuing edits.
- **Maintain Modular Structures**: Avoid packing logic directly into `App.tsx`. Extract auxiliary interfaces to `src/types.ts` and keep components grouped by role.
- **No Demolitions**: Modify components incrementally via targeted line-replacements using precision surgical diffs. Do NOT wipe functional elements.
